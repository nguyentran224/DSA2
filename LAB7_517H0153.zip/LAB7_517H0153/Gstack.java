import java.util.*;
public class Gstack<T> {
	// FIrst in last out
	private ArrayList<T> data = new ArrayList<>();
	
	public void push(T element) {
		data.add(element);	
	}
	public T pop() {
		int end = data.size() - 1;
		T element = data.get(end);
		data.remove(end);
		return element;
	}
	public boolean isEmpty() {
		return data.size() == 0;
	}
	public String toString() {
		return "Gstack [data = " + data + "]";
	}
	public static void main(String []args) {
		Gstack<String> t = new Gstack<>();
		t.push("E");
		t.push("S");
		t.push("S");
		t.push("I");
		t.push("E");
		System.out.println(t);
		String x = t.pop();
		System.out.println(x);
		x = t.pop();
		System.out.println(x);
		System.out.println(t);
	}
}
